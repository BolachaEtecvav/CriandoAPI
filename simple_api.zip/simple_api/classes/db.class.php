<?php
// conexao com o banco de dados MySQL
class DB
{
    public static function connect()
    {
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $base = 'api';

        return new PDO("mysql:host={$host}; dbname={$base};charset=UTF8;", $user, $pass);
    }
}

?>